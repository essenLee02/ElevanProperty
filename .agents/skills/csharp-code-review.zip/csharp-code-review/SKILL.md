---
name: csharp-code-review
description: C# code review skill. Analyzes code quality from OOP, SOLID, GoF design pattern, modern C# features, and performance perspectives. Use before pull requests, when optimizing code, or auditing legacy codebases.
user-invocable: true
argument-hint: "[file_path]"
context: fork
model: sonnet
allowed-tools:
  - Read
  - Glob
  - Grep
---

# C# 코드 리뷰 스킬

OOP 원칙, SOLID 원칙, GoF 디자인 패턴, 최신 C# 기능, 성능 관점에서 C# 코드를 체계적으로 리뷰합니다.

**중요: 모든 리뷰 결과는 반드시 한국어로 작성합니다.** 코드 식별자, 기술 용어, 패턴 이름 등은 원문 그대로 유지하되, 설명·문제점·개선안 등 서술 부분은 한국어를 사용합니다.

## 인자

- `$ARGUMENTS[0]`: 대상 파일 또는 디렉토리 경로 (선택, 미지정 시 최근 수정된 .cs 파일을 탐색)

## 실행 단계

### 1단계: 리뷰 대상 식별
사용자가 파일을 지정하지 않은 경우:
- 최근 수정된 `.cs` 파일 확인
- 또는 사용자에게 리뷰할 파일/디렉토리 지정 요청

### 2단계: 코드 분석
대상 코드를 읽고 아래 관점에서 분석합니다.

## 리뷰 체크리스트

### OOP 4대 원칙
| 원칙 | 리뷰 항목 |
|------|-----------|
| **캡슐화** | private 필드, 프로퍼티 접근, 구현 세부사항 은닉 |
| **상속** | 적절한 상속 계층, 상속보다 합성 우선 |
| **다형성** | 인터페이스/추상 클래스 활용, virtual 메서드 적절성 |
| **추상화** | 적절한 추상화 수준, 불필요한 세부사항 노출 |

### SOLID 원칙
| 원칙 | 리뷰 항목 | 위반 징후 |
|------|-----------|-----------|
| **SRP** | 클래스가 단일 책임을 갖는가? | 여러 이유로 클래스가 변경됨, 메서드 과다 |
| **OCP** | 확장에 열려있고 수정에 닫혀있는가? | 새 기능 추가 시 기존 코드 수정 필요, switch/if-else 체인 |
| **LSP** | 하위 타입이 상위 타입을 대체할 수 있는가? | 하위 클래스에서 예외 발생, 빈 메서드 오버라이드 |
| **ISP** | 클라이언트별로 인터페이스가 분리되어 있는가? | NotImplementedException, 미사용 메서드 |
| **DIP** | 추상화에 의존하는가? | new 직접 인스턴스화, 구체 클래스 타입 의존 |

### GoF 디자인 패턴 적용 기회
코드에서 다음 패턴을 적용할 수 있는 부분을 식별합니다:

**생성 패턴**
- 복잡한 객체 생성 → Builder
- 객체 생성 로직 분리 → Factory Method / Abstract Factory
- 전역 단일 인스턴스 → Singleton (주의: 남용 금지)

**구조 패턴**
- 호환되지 않는 인터페이스 연결 → Adapter
- 동적 기능 추가 → Decorator
- 복잡한 하위 시스템 단순화 → Facade
- 객체 트리 구조 → Composite

**행동 패턴**
- 교체 가능한 알고리즘 → Strategy
- 상태에 따른 행동 변경 → State
- 객체 간 통신 → Observer / Mediator
- 요청 처리 체인 → Chain of Responsibility
- 실행 취소/재실행 → Command + Memento

### 최신 C# 기능 (C# 12/13)
| 기능 | 권장 시점 |
|------|-----------|
| **Primary constructors** | 간단한 초기화를 가진 클래스 |
| **Collection expressions** | 배열/리스트 초기화 `[1, 2, 3]` |
| **required properties** | 생성자 없이 필수 초기화 보장 |
| **init-only setters** | 불변 객체 |
| **record types** | 값 기반 동등성, DTO |
| **Pattern matching** | 복잡한 조건문, 타입 검사 |
| **File-scoped namespaces** | 들여쓰기 축소 |
| **Raw string literals** | 여러 줄 문자열, JSON, SQL |

### 성능 리뷰
| 카테고리 | 리뷰 항목 |
|----------|-----------|
| **메모리 할당** | 핫 경로에서 불필요한 할당, Large Object Heap (>= 85KB) |
| **Async/Await** | 차단 호출 (.Result, .Wait()), ConfigureAwait 누락 |
| **컬렉션** | 잘못된 컬렉션 타입, LINQ 다중 열거 |
| **문자열** | 루프 내 문자열 결합, StringBuilder 미사용 |
| **박싱** | 불필요한 값 타입 박싱 |
| **Span/Memory** | Span<T>, Memory<T> 없는 버퍼 연산 |

### 비동기 코드 리뷰
- [ ] `.Result` 또는 `.Wait()` 호출 없음 (데드락 위험)
- [ ] 라이브러리 코드에서 `ConfigureAwait(false)` 사용
- [ ] 적절한 CancellationToken 전파
- [ ] 캐시된 결과가 있는 핫 경로에 `ValueTask` 사용
- [ ] 스트리밍 데이터에 `IAsyncEnumerable` 사용
- [ ] 이벤트 핸들러 외 async void 없음

### 코드 품질 리뷰
- [ ] 명명 규칙 (PascalCase, camelCase, _privateField, Async 접미사)
- [ ] null 안전성 (nullable reference types, `?.`, `??`, `??=`)
- [ ] 예외 처리 (구체적 예외, `when` 필터, 적절한 로깅)
- [ ] IDisposable 패턴 준수 (using 문, Dispose 구현)
- [ ] 컬렉션 사용 (적절한 타입 선택, 효율적인 LINQ)
- [ ] 매직 넘버/문자열은 상수로 선언
- [ ] 중복 코드 제거
- [ ] 상속 불필요 클래스에 `sealed` 적절히 사용

### 보안 리뷰
- [ ] 입력 유효성 검사 (SQL Injection, XSS, 경로 탐색)
- [ ] 민감 데이터 처리 (하드코딩된 비밀 없음, 적절한 암호화)
- [ ] 인증/권한 확인
- [ ] 보안 난수 생성 (`Random` 보안 용도 사용 금지)
- [ ] XML External Entity (XXE) 방지

## 3단계: 리뷰 결과 출력

### 출력 형식

모든 내용은 **한국어**로 작성합니다. 코드 식별자와 기술 용어는 원문을 유지합니다.

```markdown
# 코드 리뷰 결과

## 요약
- 파일: {파일 경로}
- 종합 평가: {우수/양호/개선 필요/심각}
- 주요 이슈: {N}건
- .NET 버전 준수: {.NET 8/9 기능 활용도}

## SOLID 원칙 분석

### SRP 위반 (심각도: 높음/보통/낮음)
- 위치: `ClassName.cs:line`
- 문제: {설명}
- 개선안: {코드 예시 포함}

### OCP 위반
...

## 최신 C# 기능 적용 기회

### {기능명} 권장
- 위치: `file.cs:line`
- 현재: {기존 코드}
- 개선: {최신 C# 문법}
- 이점: {설명}

## 성능 이슈

### {이슈 제목} (심각도: 높음/보통/낮음)
- 위치: `file.cs:line`
- 문제: {영향 포함 설명}
- 현재: {문제 코드}
- 개선: {최적화 코드}
- 효과: {예상 개선점}

## 비동기 코드 이슈

### {이슈 제목}
- 위치: `file.cs:line`
- 문제: {설명}
- 위험: {데드락/성능/기타}
- 해결: {코드 수정}

## 적용 가능한 디자인 패턴

### {패턴명} 패턴 권장
- 현재 코드: {문제점}
- 적용 시 이점: {설명}
- 예시 코드: {간략 예시}

## 보안 우려사항

### {이슈 제목} (심각도: 심각/높음/보통/낮음)
- 위치: `file.cs:line`
- 취약점: {설명}
- 해결: {코드 수정}

## 코드 품질 이슈

### {이슈 제목}
- 위치: `file.cs:line`
- 현재: {코드}
- 개선: {코드}

## 우선순위별 개선 사항
1. [심각] {보안 이슈}
2. [높음] {SOLID 위반, 성능 이슈}
3. [보통] {코드 품질, 최신 기능 적용}
4. [낮음] {스타일 개선}
```

## 가이드라인
- 수정이 필요한 이슈만 보고합니다. 긍정적 피드백은 포함하지 않습니다.
- 구체적인 코드 예시와 함께 개선안을 제시합니다.
- 과도한 엔지니어링을 권장하지 않습니다.
- 맥락을 고려한 실용적인 제안을 합니다.
- 보안 이슈를 최우선으로 다룹니다.
- 대상 .NET 버전을 고려하여 기능을 제안합니다.
- 최신 기능과 팀 친숙도 사이의 균형을 고려합니다.
